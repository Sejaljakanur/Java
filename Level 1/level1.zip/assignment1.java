import java.util.Scanner;

public class assignment1 
{

	public static void main(String[] args)
	{
		System.out.println("Values for Integer:");
		System.out.println("Minimum value="+Integer.MIN_VALUE);
		System.out.println("Maximum value="+Integer.MAX_VALUE);
		System.out.println("Memory size="+Integer.SIZE/8);
		System.out.println("\n");
		
		System.out.println("Values for Float:");
		System.out.println("Minimum value="+Float.MIN_VALUE);
		System.out.println("Maximum value="+Float.MAX_VALUE);
		System.out.println("Memory size="+Float.SIZE/8);
		System.out.println("\n");

		
		System.out.println("Values for Short:");
		System.out.println("Minimum value="+Short.MIN_VALUE);
		System.out.println("Maximum value="+Short.MAX_VALUE);
		System.out.println("Memory size="+Short.SIZE/8);
		System.out.println("\n");

		
		System.out.println("Values for Double:");
		System.out.println("Minimum value="+Double.MIN_VALUE);
		System.out.println("Maximum value="+Double.MAX_VALUE);
		System.out.println("Memory size="+Double.SIZE/8);
		System.out.println("\n");

		
		System.out.println("Values for Byte:");
		System.out.println("Minimum value="+Byte.MIN_VALUE);
		System.out.println("Maximum value="+Byte.MAX_VALUE);
		System.out.println("Memory size="+Byte.SIZE/8);
		
		
		}
}		